# Roteiro de verificação no celular

Após compilar `app-debug.apk` via Android Studio ou GitHub Actions:

1. **Ressonância fundamental**: use `n=1` (~8,10 Hz), observe amplitude e curva de ganho; espere alguns segundos simulados para o transiente.
2. **Harmônico 10**: toque em `n=10` (~81,04 Hz) e selecione `0,05×`; confirme que há dez pares de nós/ventres correspondentes ao modo ideal e que a mola muda a distância entre suas espiras, sem deslocamento transversal.
3. **Controles**: altere a amplitude de 0,1 para 2,0 mm, depois o amortecimento de 0,5 para 6,0 s⁻¹; a ressonância deve ficar mais fraca e a curva mudar.
4. **Escala visual**: ative/desative 2×; o gráfico e a física não devem mudar, só a escala do desenho da mola.
5. **Nós e ventres**: desative os marcadores e confirme que a mola continua funcionando.
6. **Varredura**: selecione varredura; o modelo deve reiniciar em 1 Hz, aumentar lentamente a frequência e mostrar o marcador deslocando-se na curva de resposta.
7. **Pausa e reinício**: pause e retome; reiniciar deve zerar o campo e o tempo mantendo a frequência ajustada.
8. **Offline**: ative modo avião e abra novamente o aplicativo.

Este roteiro ainda depende de validação em aparelho ou emulador Android real.
