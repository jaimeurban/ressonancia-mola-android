# Ressonância longitudinal em uma mola | Android nativo

Reimplementação **100% Kotlin + APIs nativas do Android** do simulador "Ressonância longitudinal em uma mola", desenvolvida para demonstrações de Física. Não há HTML, JavaScript, WebView, conexão de rede ou framework multiplataforma.

## Funcionalidades

- Simulação de onda longitudinal em mola vertical, com 52 voltas desenhadas nativamente em `Canvas`.
- Movimento com 100 segmentos, amortecimento distribuído e transientes preservados.
- Frequência contínua de 1,00 a 85,00 Hz e atalhos para os dez primeiros modos (8,10 a 81,04 Hz).
- Amplitude da base de 0,1 a 2,0 mm; amortecimento β de 0,5 a 6,0 s⁻¹.
- Reprodução Auto, 1×, 0,25×, 0,10× e 0,05×.
- Visualização opcional de nós e ventres ideais, ampliação 2×, pausa, reinício e varredura.
- Perfil de deslocamento longitudinal com envelope estacionário e gráfico de ganho em função da frequência.
- Funcionamento offline e sem permissões especiais.

## Modelo físico

M = 0,067 kg; k = 17,6 N/m; L = 0,30 m.

c = L sqrt(k/M) = 4,86228249 m/s.

fₙ = n*c/(2L) = (n/2)*sqrt(k/M).

Equação:

    ∂²u/∂t² + 2β ∂u/∂t = c² ∂²u/∂y²
    u(0,t) = 0
    u(L,t) = A sen(2π f t)

O campo u(y,t) é integrado por diferenças finitas em 100 segmentos, com passo temporal limitado pela condição CFL. Para a envoltória de regime permanente, usa-se:

    U(y) / A = sin(qy) / sin(qL)
    q = sqrt(ω² - 2iβω) / c
    G(f) = max |U(y)| / A

β é fenomenológico, e a gravidade/alongamento estático não são mostrados. Nós e ventres correspondem ao modo ideal mais próximo, não a pontos medidos durante transientes. A ampliação 2× só afeta o desenho e é reduzida automaticamente quando as espiras poderiam inverter a ordem no desenho.

## Como gerar o APK no Android Studio

1. Instale o **Android Studio** e seu Android SDK, com a plataforma **API 35**.
2. Abra a pasta `RessonanciaMolaNativa` em **Open Project**.
3. Aguarde a sincronização Gradle e, caso solicitado, instale a plataforma 35.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)** (ou execute `gradle :app:assembleDebug`).
5. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira-o ao telefone e instale; pode ser necessário autorizar a instalação de APKs de fontes externas.

O identificador de aplicativo foi alterado em relação ao APK anterior para permitir que ambos fiquem instalados. O APK de debug será assinado automaticamente pelo Android Studio.

## APK na nuvem com GitHub Actions

Há um fluxo de compilação em `.github/workflows/android-apk.yml`.

1. Crie um repositório GitHub e envie o conteúdo desta pasta à raiz dele, **incluindo a pasta oculta `.github`**.
2. Abra **Actions > Gerar APK Android nativo > Run workflow**.
3. Após a execução, abra o resultado e faça o download do artefato `RessonanciaMolaNativa-APK`.
4. Extraia o arquivo ZIP do artefato e instale `app-debug.apk` no Android.

Este fluxo requer internet e não foi executado neste ambiente.

## Organização do código

- `WaveSolver.kt`: física, diferenças finitas, amortecimento, curva teórica, câmera lenta e varredura.
- `SpringCanvasView.kt`: mola, perfil u(y,t), envelope, nós e ventres, inteiramente Canvas.
- `ResonanceChartView.kt`: gráfico de ganho e picos de ressonância.
- `MainActivity.kt`: interface nativa, controles, ciclo de vida e animação (`Choreographer`).
- `tools/TesteFisica.kt`: testes numéricos independentes de Android (compiláveis com `kotlinc`).

## Status dos testes

- Física (`WaveSolver.kt`): compilada localmente com Kotlin 1.9.0 e testes numéricos **passaram**.
- Código Kotlin Android: verificado sintaticamente contra stubs locais das APIs Android. **Isso não equivale à compilação real com SDK.**
- APK / execução no aparelho: **não compilado nem testado** neste ambiente porque Android SDK, Gradle, aapt2 e d8 não estavam disponíveis. Não use o APK WebView anterior como se fosse esta versão.
