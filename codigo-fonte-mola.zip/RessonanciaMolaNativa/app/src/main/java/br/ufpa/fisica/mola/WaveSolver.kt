package br.ufpa.fisica.mola

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.cosh
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.sqrt

/**
 * Modelo físico original, totalmente implementado em Kotlin.
 *
 * M * u_tt + 2*beta*M*u_t = M*c²*u_yy
 * u(0,t)=0, u(L,t)=A sin(2*pi*f*t)
 *
 * Posição de equilíbrio como referência; peso e extensão estática omitidos.
 * beta fenomenológico (não medido). A mudança de f mantém os transientes.
 */
class WaveSolver {
    companion object {
        const val MASS_KG = 0.067
        const val STIFFNESS_N_M = 17.6
        const val LENGTH_M = 0.30
        const val N = 100
        const val MIN_F = 1.0
        const val MAX_F = 85.0
        val C = LENGTH_M * sqrt(STIFFNESS_N_M / MASS_KG)
        val F1 = C / (2.0 * LENGTH_M)
    }

    enum class Playback(val factor: Double) {
        AUTO(-1.0), NORMAL(1.0), QUARTER(0.25), TENTH(0.1), TWENTIETH(0.05)
    }

    var frequencyHz: Double = F1
        private set
    var amplitudeMm: Double = 0.6
    var beta: Double = 2.4
    var paused: Boolean = false
    var sweeping: Boolean = false
        private set
    var magnify: Boolean = true
    var showMarkers: Boolean = true
    var playback: Playback = Playback.AUTO

    var timeSeconds: Double = 0.0
        private set
    private var sweepSeconds = 0.0

    val u = DoubleArray(N + 1)
    private val velocities = DoubleArray(N + 1)

    fun tune(hz: Double, fromSweep: Boolean = false) {
        frequencyHz = hz.coerceIn(MIN_F, MAX_F)
        if (!fromSweep) sweeping = false
    }

    fun startOrStopSweep() {
        if (sweeping) {
            sweeping = false
        } else {
            reset()
            tune(MIN_F, fromSweep = true)
            sweeping = true
            paused = false
        }
    }

    fun reset() {
        java.util.Arrays.fill(u, 0.0)
        java.util.Arrays.fill(velocities, 0.0)
        timeSeconds = 0.0
        sweepSeconds = 0.0
        sweeping = false
    }

    fun playbackFactor(): Double = when (playback) {
        Playback.AUTO -> when {
            frequencyHz <= 18.0 -> 1.0
            frequencyHz <= 40.0 -> 0.25
            else -> 0.10
        }
        else -> playback.factor
    }

    fun advance(wallSeconds: Double) {
        if (paused || wallSeconds <= 0.0) return
        val physicalSeconds = min(0.042, wallSeconds) * playbackFactor()
        if (physicalSeconds <= 0.0) return
        val dx = LENGTH_M / N
        // CFL control: c*dt/dx <= 0.32; stepping semi-implicit as in original.
        val dtMax = min(0.002, 0.32 * dx / C)
        val steps = max(1, ceil(physicalSeconds / dtMax).toInt())
        val dt = physicalSeconds / steps
        val stiffness = (C / dx) * (C / dx)
        val drag = 2.0 * beta
        val angular = 2.0 * PI * frequencyHz
        val amplitudeMeters = amplitudeMm / 1000.0
        repeat(steps) {
            u[0] = 0.0
            u[N] = amplitudeMeters * sin(angular * timeSeconds)
            for (i in 1 until N) {
                val acceleration = stiffness * (u[i + 1] - 2.0 * u[i] + u[i - 1]) - drag * velocities[i]
                velocities[i] += acceleration * dt
            }
            for (i in 1 until N) u[i] += velocities[i] * dt
            timeSeconds += dt
            u[0] = 0.0
            u[N] = amplitudeMeters * sin(angular * timeSeconds)
        }
        if (sweeping) {
            sweepSeconds += physicalSeconds
            val target = MIN_F + sweepSeconds * 0.55
            if (target >= MAX_F) {
                sweeping = false
                tune(MAX_F, fromSweep = true)
            } else if (abs(target - frequencyHz) >= 0.01) {
                tune(target, fromSweep = true)
            }
        }
    }

    fun sample(s: Double): Double {
        val x = s.coerceIn(0.0, 1.0) * N
        val i = min(N - 1, x.toInt())
        val t = x - i
        return u[i] * (1.0 - t) + u[i + 1] * t
    }

    /** Complex steady-state envelope for harmonic boundary driving. */
    data class Envelope(val gain: Double, val profile: DoubleArray)

    fun envelope(hz: Double = frequencyHz, samples: Int = N): Envelope {
        val omega = 2.0 * PI * hz
        val w2 = omega * omega
        val imagArgument = -2.0 * beta * omega
        val modulus = hypot(w2, imagArgument)
        val realK = sqrt(max(0.0, (modulus + w2) / 2.0)) / C
        val imagK = -sqrt(max(0.0, (modulus - w2) / 2.0)) / C
        val denR = sin(realK * LENGTH_M) * cosh(imagK * LENGTH_M)
        val denI = cos(realK * LENGTH_M) * sinh(imagK * LENGTH_M)
        val denAbs2 = denR * denR + denI * denI
        if (denAbs2 < 1e-30) return Envelope(0.0, DoubleArray(samples + 1))
        val profile = DoubleArray(samples + 1)
        var gain = 0.0
        for (i in 0..samples) {
            val pos = LENGTH_M * i.toDouble() / samples
            val numR = sin(realK * pos) * cosh(imagK * pos)
            val numI = cos(realK * pos) * sinh(imagK * pos)
            val r = (numR * denR + numI * denI) / denAbs2
            val im = (numI * denR - numR * denI) / denAbs2
            val amp = hypot(r, im)
            profile[i] = amp
            gain = max(gain, amp)
        }
        return Envelope(gain, profile)
    }

    fun nearestMode(): Int = round(frequencyHz / F1).toInt().coerceIn(1, 10)

    fun visualScale(): Double {
        var slope = 0.0
        for (i in 1..N) slope = max(slope, abs((u[i] - u[i-1]) * N / LENGTH_M))
        val requested = if (magnify) 2.0 else 1.0
        return if (slope > 0.0) min(requested, 0.78 / slope) else requested
    }
}
