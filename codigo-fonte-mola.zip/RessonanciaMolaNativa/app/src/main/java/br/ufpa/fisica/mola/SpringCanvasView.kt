package br.ufpa.fisica.mola

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Desenho nativo Android Canvas. Nenhuma View Web / HTML / JavaScript. */
class SpringCanvasView(context: Context, private val model: WaveSolver) : View(context) {
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    private val bg = Color.rgb(13, 25, 40)
    private val cyan = Color.rgb(112, 231, 242)
    private val orange = Color.rgb(255, 166, 56)
    private val muted = Color.rgb(161, 189, 207)
    private val violet = Color.rgb(182, 155, 236)
    private val node = Color.rgb(88, 239, 255)
    private val antinode = Color.rgb(255, 126, 214)

    private fun line(c: Canvas, x: Float, y: Float, xx: Float, yy: Float, color: Int, width: Float = 1f) {
        pen.style = Paint.Style.STROKE; pen.strokeWidth = width; pen.color = color
        c.drawLine(x, y, xx, yy, pen)
    }

    private fun rounded(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        pen.style = Paint.Style.FILL; pen.color = color
        c.drawRoundRect(l, t, r, b, rad, rad, pen)
    }

    private fun circle(c: Canvas, x: Float, y: Float, radius: Float, color: Int, stroke: Boolean = false) {
        pen.style = if (stroke) Paint.Style.STROKE else Paint.Style.FILL
        pen.strokeWidth = if (stroke) 1.8f else 1f
        pen.color = color
        c.drawCircle(x, y, radius, pen)
    }

    private fun label(c: Canvas, text: String, x: Float, y: Float, size: Float = 11f, color: Int = muted,
                      align: Paint.Align = Paint.Align.CENTER, bold: Boolean = false) {
        pen.style = Paint.Style.FILL; pen.color = color; pen.textSize = size
        pen.textAlign = align; pen.typeface = if (bold) android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) else android.graphics.Typeface.DEFAULT
        c.drawText(text, x, y, pen)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(bg)
        // A área virtual 400 × 555 conserva a composição tanto em telefones como em tablets.
        canvas.save()
        canvas.scale(width / 400f, height / 555f)
        rounded(canvas, 9f, 9f, 195f, 542f, 14f, Color.rgb(17, 34, 51))
        rounded(canvas, 203f, 9f, 392f, 542f, 14f, Color.rgb(17, 34, 51))

        val top = 71f
        val bottom = 432f
        val h = bottom - top
        val center = 101f
        val turns = 52
        val r = 29f
        val visual = model.visualScale()
        fun yy(s: Double): Float = top + (s * h + model.sample(s) * h / WaveSolver.LENGTH_M * visual).toFloat()

        label(canvas, "MOLA LONGITUDINAL", center, 31f, 10.5f, muted, bold = true)
        label(canvas, "PERFIL u(y,t)", 295f, 31f, 10.5f, muted, bold = true)
        label(canvas, "laranja = espiras", center, 49f, 9f, Color.rgb(255, 190, 119))
        label(canvas, "ciano = deslocamento", 294f, 49f, 9f, cyan)

        line(canvas, center, top - 3f, center, bottom + 8f, Color.rgb(58, 85, 106))
        line(canvas, center - 62f, bottom, center + 62f, bottom, Color.rgb(56, 88, 110))
        // Suporte superior fixo
        rounded(canvas, center - 65f, top - 17f, center + 65f, top - 7f, 3f, Color.rgb(91, 112, 131))
        for (i in -3..3) line(canvas, center + i * 19f - 6f, top - 15f, center + i * 19f, top - 9f, Color.rgb(32, 50, 67), 2f)
        rounded(canvas, center - 10f, top - 8f, center + 10f, top + 7f, 4f, Color.rgb(120, 148, 164))

        // Os 52 elos são desenhados na mesma cor, variando a separação longitudinal.
        path.reset()
        for (i in 0..(turns * 18)) {
            val s = i.toDouble() / (turns * 18)
            val x = center + r * sin(s * turns * 2.0 * PI).toFloat()
            val y = yy(s)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        pen.style = Paint.Style.STROKE; pen.strokeWidth = 7f; pen.color = Color.rgb(5, 14, 25)
        canvas.drawPath(path, pen)
        pen.strokeWidth = 4.2f; pen.color = orange
        canvas.drawPath(path, pen)
        circle(canvas, center, yy(12.0 / turns), 4.3f, orange)

        if (model.showMarkers) {
            val n = model.nearestMode()
            val exact = abs(model.frequencyHz / WaveSolver.F1 - n) < 0.14
            label(canvas, if (exact) "Nós e ventres: n=$n" else "Modo próximo: n=$n", center, 61f, 8.7f)
            for (m in 0..n) {
                val y = yy(m.toDouble() / n)
                line(canvas, center - r - 10f, y, center + r + 10f, y, Color.argb(120, 88, 239, 255), .9f)
                circle(canvas, center, y, 5f, Color.rgb(25, 57, 70))
                circle(canvas, center, y, 4.5f, node, true)
            }
            for (m in 0 until n) {
                val y = yy((m + 0.5) / n)
                path.reset()
                path.moveTo(center - 8f, y); path.lineTo(center, y - 6f)
                path.lineTo(center + 8f, y); path.lineTo(center, y + 6f); path.close()
                pen.style = Paint.Style.FILL; pen.color = Color.rgb(85, 32, 83); canvas.drawPath(path, pen)
                pen.style = Paint.Style.STROKE; pen.strokeWidth = 1.8f; pen.color = antinode; canvas.drawPath(path, pen)
            }
        }

        val baseY = yy(1.0)
        line(canvas, center - 13f, baseY, center + 13f, baseY, Color.rgb(196, 224, 236), 4f)
        line(canvas, center, baseY, center, baseY + 13f, Color.rgb(196, 224, 236), 3f)
        rounded(canvas, center - 55f, baseY + 12f, center + 55f, baseY + 46f, 8f, Color.rgb(47, 80, 104))
        label(canvas, "OSCILADOR", center, baseY + 34f, 11f, Color.WHITE, bold = true)
        line(canvas, center + r + 16f, baseY - 24f, center + r + 16f, baseY + 14f, cyan, 2f)
        line(canvas, center + r + 11f, baseY - 17f, center + r + 16f, baseY - 24f, cyan, 2f)
        line(canvas, center + r + 21f, baseY - 17f, center + r + 16f, baseY - 24f, cyan, 2f)
        line(canvas, center + r + 11f, baseY + 7f, center + r + 16f, baseY + 14f, cyan, 2f)
        line(canvas, center + r + 21f, baseY + 7f, center + r + 16f, baseY + 14f, cyan, 2f)
        label(canvas, "fixo", 151f, top - 3f, 9.7f)
        label(canvas, "L = 0,30 m", 52f, 518f, 10f)
        label(canvas, "t = ${String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", model.timeSeconds)} s", 151f, 518f, 10f)
        if (visual < (if (model.magnify) 2.0 else 1.0) - 0.05) {
            label(canvas, "Escala visual limitada: ${String.format(java.util.Locale.US, "%.1f", visual)}×", center, 536f, 9f, Color.rgb(243, 199, 140))
        }

        // Gráfico de u(y,t): abscissa = deslocamento axial; ordenada = posição y.
        val gl = 213f; val gr = 384f; val gx = (gl + gr) / 2f
        val env = model.envelope()
        var maxReal = 0.0
        for (valU in model.u) maxReal = max(maxReal, abs(valU))
        val xMax = max(0.014, max(model.amplitudeMm / 1000.0 * env.gain * 1.28, maxReal * 1.18))
        fun xx(u: Double): Float = gx + (u / xMax * 70.0).toFloat()
        for (k in -2..2) {
            line(canvas, xx(k * xMax / 2.0), top, xx(k * xMax / 2.0), bottom,
                if (k == 0) Color.rgb(112, 146, 165) else Color.rgb(45, 71, 91), if (k == 0) 1.5f else .8f)
        }
        for (j in 0..4) {
            val y = top + h * j / 4f
            line(canvas, gl, y, gr, y, Color.rgb(51, 76, 93), .8f)
            label(canvas, "${String.format(java.util.Locale.US, "%.3f", j * WaveSolver.LENGTH_M / 4.0)} m", 218f, y - 5f, 8f,
                Color.rgb(134, 157, 171), Paint.Align.LEFT)
        }
        // Curvas teóricas +/- A |sin(ky)/sin(kL)| no regime permanente.
        for (sign in doubleArrayOf(-1.0, 1.0)) {
            path.reset()
            for (j in 0..WaveSolver.N) {
                val x = xx(sign * model.amplitudeMm / 1000.0 * env.profile[j])
                val y = top + h * j / WaveSolver.N
                if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            pen.style = Paint.Style.STROKE; pen.strokeWidth = 1.6f
            pen.color = Color.argb(165, 182, 155, 236)
            pen.pathEffect = android.graphics.DashPathEffect(floatArrayOf(5f, 5f), 0f)
            canvas.drawPath(path, pen); pen.pathEffect = null
        }
        path.reset()
        for (j in 0..WaveSolver.N) {
            val x = xx(model.u[j]); val y = top + h * j / WaveSolver.N
            if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        pen.style = Paint.Style.STROKE; pen.strokeWidth = 2.8f; pen.color = cyan
        canvas.drawPath(path, pen)
        circle(canvas, xx(model.u[WaveSolver.N]), bottom, 4f, Color.rgb(255, 211, 153))
        label(canvas, "−${(xMax * 1000).toInt()} mm", gl, 475f, 9f, muted, Paint.Align.LEFT)
        label(canvas, "0", gx, 475f, 10f)
        label(canvas, "+${(xMax * 1000).toInt()} mm", gr, 475f, 9f, muted, Paint.Align.RIGHT)
        label(canvas, "DESLOCAMENTO LONGITUDINAL", gx, 495f, 9.3f, muted)
        line(canvas, 246f, 518f, 258f, 518f, cyan, 2.5f)
        label(canvas, "atual", 262f, 522f, 9f, muted, Paint.Align.LEFT)
        pen.pathEffect = android.graphics.DashPathEffect(floatArrayOf(4f, 4f), 0f)
        line(canvas, 311f, 518f, 323f, 518f, violet, 1.5f); pen.pathEffect = null
        label(canvas, "envelope", 326f, 522f, 9f, muted, Paint.Align.LEFT)
        canvas.restore()
    }
}
