package br.ufpa.fisica.mola

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.ceil
import kotlin.math.max

/** Curva de ganho G(f), calculada em regime permanente para o mesmo beta. */
class ResonanceChartView(context: Context, private val model: WaveSolver) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val sampleCount = 530
    private val samples = DoubleArray(sampleCount + 1)
    private var lastBeta = Double.NaN
    private var maxGain = 2.0

    private fun recomputeIfNeeded() {
        if (model.beta == lastBeta) return
        lastBeta = model.beta
        maxGain = 2.0
        for (i in 0..sampleCount) {
            val f = WaveSolver.MIN_F + (WaveSolver.MAX_F - WaveSolver.MIN_F) * i / sampleCount
            samples[i] = model.envelope(f, 100).gain
            maxGain = max(maxGain, samples[i])
        }
        maxGain = ceil(maxGain * 1.12)
    }

    private fun line(c: Canvas, x: Float, y: Float, xx: Float, yy: Float,
                     col: Int, width: Float = 1f, dashed: Boolean = false) {
        paint.style = Paint.Style.STROKE; paint.color = col; paint.strokeWidth = width
        paint.pathEffect = if (dashed) DashPathEffect(floatArrayOf(4f, 4f), 0f) else null
        c.drawLine(x, y, xx, yy, paint); paint.pathEffect = null
    }
    private fun label(c: Canvas, txt: String, x: Float, y: Float, align: Paint.Align = Paint.Align.CENTER,
                      size: Float = 10f, color: Int = Color.rgb(153, 178, 196)) {
        paint.style = Paint.Style.FILL; paint.color = color; paint.textSize = size; paint.textAlign = align
        paint.typeface = android.graphics.Typeface.DEFAULT
        c.drawText(txt, x, y, paint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(17, 34, 51))
        recomputeIfNeeded()
        canvas.save()
        canvas.scale(width / 400f, height / 235f)
        val l = 38f; val r = 389f; val top = 18f; val bottom = 196f
        fun x(f: Double) = l + ((f - WaveSolver.MIN_F) / (WaveSolver.MAX_F - WaveSolver.MIN_F) * (r - l)).toFloat()
        fun y(g: Double) = bottom - (g / maxGain * (bottom - top)).toFloat()
        for (j in 0..4) {
            val g = maxGain * j / 4.0
            val py = y(g)
            line(canvas, l, py, r, py, Color.rgb(52, 76, 94), dashed = true)
            label(canvas, String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", g), l - 5f, py + 4f, Paint.Align.RIGHT, 9f)
        }
        label(canvas, "ganho", 8f, 12f, Paint.Align.LEFT, 9f)
        for (tick in intArrayOf(1, 20, 40, 60, 80)) {
            label(canvas, "$tick Hz", x(tick.toDouble()), 220f, size = 10f)
        }
        for (n in 1..10) {
            val fn = WaveSolver.F1 * n
            if (fn > WaveSolver.MAX_F) continue
            val px = x(fn)
            line(canvas, px, top, px, bottom, Color.argb(90, 182, 155, 236), dashed = true)
            label(canvas, "$n", px, top + 12f + (if (n % 2 == 0) 10f else 0f), size = 9f,
                color = Color.rgb(199, 175, 255))
        }
        path.reset()
        for (i in 0..sampleCount) {
            val f = WaveSolver.MIN_F + (WaveSolver.MAX_F - WaveSolver.MIN_F) * i / sampleCount
            if (i == 0) path.moveTo(x(f), y(samples[i])) else path.lineTo(x(f), y(samples[i]))
        }
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.8f; paint.color = Color.rgb(101, 223, 229)
        paint.pathEffect = null; canvas.drawPath(path, paint)
        val markerX = x(model.frequencyHz)
        val markerY = y(model.envelope(model.frequencyHz, 50).gain)
        line(canvas, markerX, top, markerX, bottom, Color.rgb(255, 214, 156), 1.6f, true)
        paint.style = Paint.Style.FILL; paint.color = Color.rgb(255, 214, 156)
        canvas.drawCircle(markerX, markerY, 5f, paint)
        canvas.restore()
    }
}
