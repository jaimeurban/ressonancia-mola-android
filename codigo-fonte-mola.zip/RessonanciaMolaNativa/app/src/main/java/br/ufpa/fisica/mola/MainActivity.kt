package br.ufpa.fisica.mola

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import java.util.Locale

/** Interface inteiramente Android nativa: Activity, Views, Canvas e Choreographer. */
class MainActivity : Activity(), Choreographer.FrameCallback {
    private val model = WaveSolver()
    private lateinit var springView: SpringCanvasView
    private lateinit var chartView: ResonanceChartView
    private lateinit var frequencySlider: SeekBar
    private lateinit var freqLabel: TextView
    private lateinit var relativeLabel: TextView
    private lateinit var amplitudeLabel: TextView
    private lateinit var dampingLabel: TextView
    private lateinit var playbackLabel: TextView
    private lateinit var gainLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var pauseButton: Button
    private lateinit var sweepButton: Button
    private val modeButtons = mutableListOf<Button>()
    private val speedButtons = mutableMapOf<WaveSolver.Playback, Button>()
    private var changingProgrammatically = false
    private var rendering = false
    private var lastNanos = 0L
    private var lastDisplayedHz = Double.NaN

    companion object {
        private val BG = Color.rgb(8, 17, 29)
        private val PANEL = Color.rgb(19, 32, 50)
        private val ELEVATED = Color.rgb(36, 56, 75)
        private val ACCENT = Color.rgb(93, 224, 230)
        private val TEXT = Color.rgb(236, 246, 255)
        private val SUB = Color.rgb(167, 190, 208)
        private val GOLD = Color.rgb(255, 188, 109)
    }

    private fun dp(n: Float): Int = (resources.displayMetrics.density * n + .5f).toInt()
    private fun format(n: Double, digits: Int = 2): String = String.format(Locale.forLanguageTag("pt-BR"), "%.${digits}f", n)
    private fun roundBackground(color: Int, radius: Float = 16f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setLineSpacing(dp(2f).toFloat(), 1.06f)
        }

    private fun vertical(padding: Float = 0f): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        if (padding > 0) setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
    }

    private fun horizontal(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
    }

    private fun addSpace(parent: LinearLayout, h: Float) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }
    private fun card(parent: LinearLayout, pad: Float = 13f): LinearLayout {
        val v = vertical(pad)
        v.background = roundBackground(PANEL)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(12f)
        parent.addView(v, lp)
        return v
    }
    private fun button(label: String, selected: Boolean = false): Button = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(if (selected) BG else TEXT)
        textSize = 11.5f; minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(4f), dp(7f), dp(4f), dp(7f))
        background = roundBackground(if (selected) ACCENT else ELEVATED, 11f)
        elevation = 0f
    }
    private fun setSelected(b: Button, selected: Boolean) {
        b.setTextColor(if (selected) BG else TEXT)
        b.background = roundBackground(if (selected) ACCENT else ELEVATED, 11f)
    }
    private fun simpleSeek(initial: Int, total: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            max = total
            progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(GOLD)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    if (!changingProgrammatically) onChange(value)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false; setBackgroundColor(BG) }
        val root = vertical(13f)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("LABORATÓRIO VIRTUAL  •  FÍSICA", 10f, ACCENT, true))
        addSpace(root, 5f)
        root.addView(text("Ressonância longitudinal em uma mola", 24f, TEXT, true))
        addSpace(root, 6f)
        root.addView(text("Extremidade superior fixa e base acionada verticalmente. Observe as compressões e distensões das espiras.", 12.5f, SUB))
        addSpace(root, 14f)

        val simulationCard = card(root, 6f)
        springView = SpringCanvasView(this, model)
        simulationCard.addView(springView, LinearLayout.LayoutParams(-1, dp(540f)))
        val visualOptions = horizontal()
        val markers = CheckBox(this).apply {
            text = "Nós e ventres"; textSize = 12f; setTextColor(TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(ACCENT)
            isChecked = model.showMarkers
            setOnCheckedChangeListener { _, checked -> model.showMarkers = checked; springView.invalidate() }
        }
        val magnify = CheckBox(this).apply {
            text = "Ampliar 2×"; textSize = 12f; setTextColor(TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(ACCENT)
            isChecked = model.magnify
            setOnCheckedChangeListener { _, checked -> model.magnify = checked; springView.invalidate() }
        }
        visualOptions.addView(markers, LinearLayout.LayoutParams(0, -2, 1f))
        visualOptions.addView(magnify, LinearLayout.LayoutParams(0, -2, 1f))
        simulationCard.addView(visualOptions)
        simulationCard.addView(text("Ciano: nós e deslocamento  •  Rosa: ventres  •  Laranja: espiras", 10.5f, SUB))

        val controls = card(root)
        val heading = horizontal()
        heading.addView(text("Frequência de excitação", 15f, TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        relativeLabel = text("f/f₁ = 1,00", 12f, ACCENT, true)
        heading.addView(relativeLabel)
        controls.addView(heading)
        addSpace(controls, 7f)
        freqLabel = text("${format(model.frequencyHz)} Hz", 29f, GOLD, true)
        controls.addView(freqLabel)
        frequencySlider = simpleSeek(((model.frequencyHz - 1.0) * 100).toInt(), 8400) {
            model.tune(1.0 + it / 100.0)
            refreshLabels()
        }
        controls.addView(frequencySlider)
        val minmax = horizontal().apply {
            addView(text("1,00 Hz", 10.5f, SUB), LinearLayout.LayoutParams(0, -2, 1f))
            addView(text("85,00 Hz", 10.5f, SUB))
        }
        controls.addView(minmax)
        addSpace(controls, 12f)
        controls.addView(text("Atalhos: dez modos harmônicos", 12f, SUB, true))
        addSpace(controls, 6f)
        for (rowIndex in 0..1) {
            val row = horizontal()
            for (col in 0..4) {
                val n = rowIndex * 5 + col + 1
                val b = button("n=$n\n${format(n * WaveSolver.F1, 1)} Hz")
                b.setOnClickListener { model.tune(n * WaveSolver.F1); refreshLabels() }
                modeButtons.add(b)
                val p = LinearLayout.LayoutParams(0, dp(53f), 1f)
                p.setMargins(dp(2f), dp(2f), dp(2f), dp(2f))
                row.addView(b, p)
            }
            controls.addView(row)
        }
        addSpace(controls, 9f)
        controls.addView(text("Frequências naturais calculadas a partir da massa e da constante elástica.", 11f, SUB))

        val speedCard = card(root)
        val speedTitle = horizontal()
        speedTitle.addView(text("Velocidade de reprodução", 14f, TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        playbackLabel = text("1×", 12f, ACCENT, true)
        speedTitle.addView(playbackLabel)
        speedCard.addView(speedTitle)
        addSpace(speedCard, 9f)
        val rates = horizontal()
        for ((mode, title) in listOf(
            WaveSolver.Playback.AUTO to "Auto", WaveSolver.Playback.NORMAL to "1×",
            WaveSolver.Playback.QUARTER to "0,25×", WaveSolver.Playback.TENTH to "0,10×",
            WaveSolver.Playback.TWENTIETH to "0,05×"
        )) {
            val b = button(title, mode == model.playback)
            b.setOnClickListener { model.playback = mode; refreshLabels() }
            val p = LinearLayout.LayoutParams(0, dp(46f), 1f)
            p.setMargins(dp(2f), dp(1f), dp(2f), dp(1f)); rates.addView(b, p)
            speedButtons[mode] = b
        }
        speedCard.addView(rates)
        speedCard.addView(text("O tempo simulado fica mais lento; a frequência física e a velocidade da onda não mudam.", 11f, SUB))

        val parameterCard = card(root)
        parameterCard.addView(text("Amplitude do oscilador", 14f, TEXT, true))
        amplitudeLabel = text("0,6 mm", 18f, GOLD, true)
        parameterCard.addView(amplitudeLabel)
        parameterCard.addView(simpleSeek(5, 19) {
            model.amplitudeMm = 0.1 + it * 0.1
            refreshLabels()
        })
        addSpace(parameterCard, 9f)
        parameterCard.addView(text("Amortecimento β", 14f, TEXT, true))
        dampingLabel = text("2,40 s⁻¹", 18f, GOLD, true)
        parameterCard.addView(dampingLabel)
        parameterCard.addView(simpleSeek(19, 55) {
            model.beta = 0.5 + it * 0.1
            refreshLabels()
        })

        val fixed = card(root)
        fixed.addView(text("PARÂMETROS DA MOLA", 11f, ACCENT, true))
        addSpace(fixed, 8f)
        fixed.addView(text("M = 0,067 kg     k = 17,6 N/m     L = 0,30 m", 13f, TEXT))
        fixed.addView(text("v = L√(k/M) = ${format(WaveSolver.C, 3)} m/s", 13f, SUB))
        fixed.addView(text("f₁ = ½√(k/M) = ${format(WaveSolver.F1, 2)} Hz", 13f, SUB))
        addSpace(fixed, 10f)
        gainLabel = text("Ganho previsto: …", 16f, GOLD, true)
        fixed.addView(gainLabel)
        addSpace(fixed, 10f)
        val actions = horizontal()
        pauseButton = button("⏸ Pausar")
        pauseButton.setOnClickListener { model.paused = !model.paused; refreshLabels() }
        val restart = button("↺ Reiniciar")
        restart.setOnClickListener { model.reset(); refreshLabels(); springView.invalidate() }
        sweepButton = button("↗ Varredura")
        sweepButton.setOnClickListener { model.startOrStopSweep(); refreshLabels() }
        for (b in arrayOf(pauseButton, restart, sweepButton)) {
            val p = LinearLayout.LayoutParams(0, dp(49f), 1f)
            p.setMargins(dp(2f), 0, dp(2f), 0)
            actions.addView(b, p)
        }
        fixed.addView(actions)

        val chartCard = card(root, 7f)
        chartCard.addView(text("  CURVA DE RESSONÂNCIA", 13f, TEXT, true))
        chartCard.addView(text("  Ganho máximo de deslocamento interno / amplitude do oscilador", 10f, SUB))
        addSpace(chartCard, 6f)
        chartView = ResonanceChartView(this, model)
        chartCard.addView(chartView, LinearLayout.LayoutParams(-1, dp(235f)))
        addSpace(chartCard, 7f)

        val explanation = card(root)
        explanation.addView(text("O QUE ESTÁ ACONTECENDO?", 12f, ACCENT, true))
        addSpace(explanation, 6f)
        statusLabel = text("", 12.5f, TEXT)
        explanation.addView(statusLabel)
        addSpace(explanation, 10f)
        explanation.addView(text("MODELO FÍSICO E LIMITAÇÕES", 12f, ACCENT, true))
        addSpace(explanation, 7f)
        explanation.addView(text(
            "∂²u/∂t² + 2β ∂u/∂t = v² ∂²u/∂y²\n\n" +
            "u(0,t) = 0              u(L,t) = A sen(2πft)\n\n" +
            "Integração temporal por diferenças finitas em 100 segmentos. " +
            "A curva de ressonância usa a resposta harmônica estacionária da mesma equação. " +
            "Os marcadores de nós e ventres indicam o modo ideal mais próximo, " +
            "não pontos medidos durante os transientes.\n\n" +
            "O amortecimento β é fenomenológico; não foi medido na mola real. " +
            "O alongamento estático devido à gravidade não está desenhado. " +
            "O fator de ampliação altera só a visualização, jamais os cálculos físicos. " +
            "Em deformações grandes, a escala visual é limitada para evitar cruzamentos artificiais das espiras.",
            12f, SUB
        ))
        addSpace(root, 4f)
        root.addView(text("Desenvolvido em Kotlin · Android Canvas · Funciona offline · Sem WebView", 11f, SUB))
        addSpace(root, 16f)
        refreshLabels()
    }

    private fun refreshLabels() {
        if (!::freqLabel.isInitialized) return
        freqLabel.text = "${format(model.frequencyHz)} Hz"
        relativeLabel.text = "f/f₁ = ${format(model.frequencyHz / WaveSolver.F1)}"
        amplitudeLabel.text = "${format(model.amplitudeMm, 1)} mm"
        dampingLabel.text = "${format(model.beta)} s⁻¹"
        val rate = model.playbackFactor()
        playbackLabel.text = if (model.playback == WaveSolver.Playback.AUTO) "Auto (${format(rate, 2)}×)" else "${format(rate, 2)}×"
        speedButtons.forEach { (mode, b) -> setSelected(b, mode == model.playback) }
        for ((i, b) in modeButtons.withIndex()) {
            setSelected(b, abs(model.frequencyHz - (i + 1) * WaveSolver.F1) < 0.035)
        }
        changingProgrammatically = true
        frequencySlider.progress = ((model.frequencyHz - WaveSolver.MIN_F) * 100).toInt().coerceIn(0, 8400)
        changingProgrammatically = false
        gainLabel.text = "Ganho previsto: ${format(model.envelope().gain)}×"
        pauseButton.text = if (model.paused) "▶ Continuar" else "⏸ Pausar"
        sweepButton.text = if (model.sweeping) "■ Parar varredura" else "↗ Varredura"
        val nearest = model.nearestMode()
        val detune = abs(model.frequencyHz / WaveSolver.F1 - nearest)
        statusLabel.text = when {
            detune < 0.08 -> "Excitação próxima do modo n=$nearest. A amplitude interna aumenta gradualmente até o regime estacionário, limitado pelo amortecimento."
            detune < 0.25 -> "A frequência está na vizinhança do modo n=$nearest. Observe a resposta e os transientes após mudar a frequência."
            else -> "Fora dos picos de ressonância, a amplitude interna tende a ser menor. Compare a mola, o perfil de deslocamento e o gráfico de ganho."
        }
        lastDisplayedHz = model.frequencyHz
        springView.invalidate(); chartView.invalidate()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!rendering) return
        if (lastNanos > 0L) {
            val elapsed = ((frameTimeNanos - lastNanos).toDouble() / 1_000_000_000.0).coerceIn(0.0, 0.042)
            model.advance(elapsed)
            if (abs(model.frequencyHz - lastDisplayedHz) >= 0.04) refreshLabels()
            springView.invalidate()
        }
        lastNanos = frameTimeNanos
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onResume() {
        super.onResume()
        lastNanos = 0L
        rendering = true
        Choreographer.getInstance().postFrameCallback(this)
    }
    override fun onPause() {
        rendering = false
        Choreographer.getInstance().removeFrameCallback(this)
        super.onPause()
    }
}
