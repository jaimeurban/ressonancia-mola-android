import br.ufpa.fisica.mola.WaveSolver
import kotlin.math.*

fun main() {
    val m = WaveSolver()
    assert(abs(WaveSolver.C - 4.862) < 0.01)
    assert(abs(WaveSolver.F1 - 8.104) < 0.01)
    assert(abs(WaveSolver.F1 * 10 - 81.04) < 0.1)
    val peak = m.envelope(WaveSolver.F1).gain
    val off = m.envelope(3.0).gain
    check(peak > off) { "Pico nao maior que off resonance: peak=$peak off=$off" }
    repeat(120) { m.advance(1.0 / 60.0) }
    check(m.u.all { it.isFinite() }) { "Numerical solver diverged" }
    check(m.u.maxOf { abs(it) } < 0.10) { "Numerical solver physically implausible" }
    m.paused = true
    val oldTime = m.timeSeconds
    m.advance(.01)
    check(m.timeSeconds == oldTime)
    m.paused = false
    m.startOrStopSweep()
    check(m.sweeping && abs(m.frequencyHz-1.0)<0.001 && abs(m.timeSeconds)<0.001)
    repeat(60) { m.advance(.0166) }
    check(m.frequencyHz > 1.45 && m.frequencyHz < 1.7)
    check(m.envelope().gain.isFinite())
    println("OK: c=${WaveSolver.C}, f1=${WaveSolver.F1}, peak=$peak, off=$off, t=${m.timeSeconds}, fsweep=${m.frequencyHz}")
}
